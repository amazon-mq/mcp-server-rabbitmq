"""Test package for RabbitMQ MCP Server."""
