"""Constants for the RabbitMQ MCP server."""

MCP_SERVER_VERSION = "2.2.0"
