"""RabbitMQ MCP Server package."""
